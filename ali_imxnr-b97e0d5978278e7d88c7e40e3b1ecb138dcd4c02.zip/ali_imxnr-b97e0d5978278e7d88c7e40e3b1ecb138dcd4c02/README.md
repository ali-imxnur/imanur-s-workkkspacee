- 👋 Hi, I’m @imaanx
- 👀 I’m interested in ... Java full stack, Software Testing, Database
- 🌱 I’m currently learning ... Core java, Manual testing,Sql
- 💞️ I’m looking to collaborate on ... Java Developer and Tester
- 📫 How to reach me ... www.facebook.com/imanur.ali01 @imaan_ur

<!---
imaanx/imaanx is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
